此包不包含 /home/sqwan（它应由单独 home tar 备份），也不包含 Buildroot 下载缓存或完整 WSL 系统。
用于新 Linux 重建环境：先阅读 packages/apt-manual.txt 和 packages/dpkg-versions.tsv，配置 config/etc-selected.tar 中的 APT 源，再安装所需工具链。
